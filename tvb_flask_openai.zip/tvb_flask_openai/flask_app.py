"""
TVB 2026 - Flask + OpenAI API Demo

Expected files in the same directory as this file:

    flask_app.py
    api_key.txt
    api_org.txt
    templates/
        index.html

The API key and organization ID are read from files and are NOT written
directly into the Python source code.

PythonAnywhere:
    Web -> WSGI configuration

Use:

    from flask_app import app as application
"""

from pathlib import Path
import base64
import os
import uuid

from flask import Flask, jsonify, render_template, request, url_for
from werkzeug.utils import secure_filename


# ============================================================
# 0. OPENAI
# ============================================================

from openai import OpenAI, DefaultHttpx2Client

filename = "api_key.txt"
with open(filename, "r") as file:
    api_key = file.read().strip()

filename = "api_org.txt"
with open(filename, "r") as file:
    api_key2 = file.read().strip()

http_client = DefaultHttpx2Client(
    headers={
        "Accept-Encoding": "identity"
    }
)

client = OpenAI(
    api_key=api_key,
    organization=api_key2,
    http_client=http_client
)


# ============================================================
# 1. FOLDERS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

STATIC_DIR = BASE_DIR / "static"
GENERATED_DIR = STATIC_DIR / "generated"
UPLOAD_DIR = STATIC_DIR / "uploads"

GENERATED_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. READ API KEYS
# ============================================================

def read_key(filename):
    """
    Read a key from a text file located next to flask_app.py.
    """
    path = BASE_DIR / filename

    if not path.exists():
        raise FileNotFoundError(
            "Could not find {}. Put it in the same directory as flask_app.py.".format(
                filename
            )
        )

    value = path.read_text(encoding="utf-8").strip()

    if not value:
        raise ValueError("{} exists but is empty.".format(filename))

    return value






# ============================================================
# 4. MODELS
# ============================================================
#
# These can be changed without changing the rest of the program.
#
# Example in PythonAnywhere:
#
# OPENAI_TEXT_MODEL=gpt-5.6-luna
#
# The text model is used for:
#   - Ask AI
#   - Sentiment
#   - Translation
#   - Startup tagline
#   - Vision
#   - Streaming
#

TEXT_MODEL = os.environ.get(
    "OPENAI_TEXT_MODEL",
    "gpt-5.6-luna"
)

IMAGE_MODEL = os.environ.get(
    "OPENAI_IMAGE_MODEL",
    "gpt-image-2"
)

TTS_MODEL = os.environ.get(
    "OPENAI_TTS_MODEL",
    "gpt-4o-mini-tts"
)

STT_MODEL = os.environ.get(
    "OPENAI_STT_MODEL",
    "gpt-4o-transcribe"
)


# ============================================================
# 5. FLASK APP
# ============================================================

app = Flask(__name__)

# Maximum uploaded audio file size: 25 MB
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024


# ============================================================
# 6. GENERAL HELPER FUNCTIONS
# ============================================================

def error_response(exc):
    """
    Log the full exception to the PythonAnywhere error log
    and send a readable error message to the browser.
    """
    app.logger.exception("OpenAI API error")

    return jsonify({
        "error": "{}: {}".format(type(exc).__name__, str(exc))
    }), 500


def get_chat_text(prompt, system_prompt=None):
    """
    Call the OpenAI Chat Completions API.

    This deliberately follows the structure used in the original
    notebook:

        response = myclient.chat.completions.create(
            model="...",
            messages=[
                {"role": "user", "content": "..."}
            ]
        )

        response.choices[0].message.content
    """

    messages = []

    if system_prompt:
        messages.append({
            "role": "system",
            "content": system_prompt
        })

    messages.append({
        "role": "user",
        "content": prompt
    })

    print("1.1",prompt)
    response = client.chat.completions.create(
        model=TEXT_MODEL,
        messages=messages
    )
    print("1.2",response.choices[0].message.content.strip())
    return response.choices[0].message.content.strip()


def allowed_audio(filename):
    """
    Check whether the uploaded audio file has a supported extension.
    """
    allowed_extensions = {
        "mp3",
        "wav",
        "m4a",
        "mp4",
        "mpeg",
        "mpga",
        "webm",
        "ogg",
        "flac"
    }

    if "." not in filename:
        return False

    extension = filename.rsplit(".", 1)[1].lower()

    return extension in allowed_extensions


# ============================================================
# 7. HOME PAGE
# ============================================================

@app.route("/")
def index():
    return render_template(
        "index.html",
        text_model=TEXT_MODEL,
        image_model=IMAGE_MODEL,
        tts_model=TTS_MODEL,
        stt_model=STT_MODEL
    )


# ============================================================
# 8. ASK AI
# ============================================================

@app.route("/api/ask", methods=["POST"])
def ask():

    prompt = request.form.get("prompt", "").strip()
    # Let's ask another examle question:
    question = "What are the most common cars?  I want a short list of 5 with 10 words per item"
    print("1.1",question)
    response = client.chat.completions.create(
      model="gpt-3.5-turbo",
      messages=[
            {"role": "user", "content": question}
        ]
    )
    print("1.2",response.choices[0].message.content.strip())
    return jsonify({
            "result": response.choices[0].message.content
        })


# ============================================================
# 9. SENTIMENT ANALYSIS
# ============================================================

@app.route("/api/sentiment", methods=["POST"])
def sentiment():

    statement = request.form.get("statement", "").strip()

    if not statement:
        return jsonify({
            "error": "Please enter a statement."
        }), 400

    try:

        system_prompt = (
            "You are a sentiment analyzer. "
            "Answer with exactly one lowercase word: "
            "positive or negative."
        )

        result = get_chat_text(
            statement,
            system_prompt=system_prompt
        )

        return jsonify({
            "result": result
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 10. TRANSLATION
# ============================================================

@app.route("/api/translate", methods=["POST"])
def translate():

    statement = request.form.get("statement", "").strip()

    language = request.form.get(
        "language",
        "Irish"
    ).strip()

    if not language:
        language = "Irish"

    if not statement:
        return jsonify({
            "error": "Please enter text to translate."
        }), 400

    try:

        prompt = (
            "Translate the following text into {}.\n\n"
            "{}"
        ).format(
            language,
            statement
        )

        result = get_chat_text(prompt)

        return jsonify({
            "result": result
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 11. STARTUP TAGLINE
# ============================================================

@app.route("/api/tagline", methods=["POST"])
def tagline():

    company = request.form.get(
        "company",
        "Ferrari"
    ).strip()

    if not company:
        company = "Ferrari"

    try:

        prompt = (
            "Write a memorable marketing tagline for {} "
            "in 15 words or fewer. "
            "Use the word {}."
        ).format(
            company,
            company
        )

        result = get_chat_text(prompt)

        return jsonify({
            "result": result
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 12. IMAGE GENERATION
# ============================================================

@app.route("/api/image", methods=["POST"])
def image_generate():

    prompt = request.form.get(
        "prompt",
        ""
    ).strip()

    if not prompt:
        return jsonify({
            "error": "Please enter an image prompt."
        }), 400

    try:

        result = client.images.generate(
            model=IMAGE_MODEL,
            prompt=prompt,
            size="1024x1024"
        )

        image = result.data[0]

        # ----------------------------------------------------
        # Newer image models may return base64 data.
        # ----------------------------------------------------

        b64_data = getattr(
            image,
            "b64_json",
            None
        )

        if b64_data:

            image_bytes = base64.b64decode(b64_data)

            filename = "image_{}.png".format(
                uuid.uuid4().hex
            )

            filepath = GENERATED_DIR / filename

            filepath.write_bytes(image_bytes)

            image_url = url_for(
                "static",
                filename="generated/{}".format(filename)
            )

            return jsonify({
                "url": image_url
            })

        # ----------------------------------------------------
        # Some image models may return a URL.
        # ----------------------------------------------------

        image_url = getattr(
            image,
            "url",
            None
        )

        if image_url:

            return jsonify({
                "url": image_url
            })

        return jsonify({
            "error": "The image API returned no image data."
        }), 500

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 13. VISION
# ============================================================

@app.route("/api/vision", methods=["POST"])
def vision():

    image_url = request.form.get(
        "image_url",
        ""
    ).strip()

    question = request.form.get(
        "question",
        "What's in this image?"
    ).strip()

    if not image_url:
        return jsonify({
            "error": "Please provide a public image URL."
        }), 400

    try:

        response = client.chat.completions.create(

            model=TEXT_MODEL,

            messages=[

                {
                    "role": "user",

                    "content": [

                        {
                            "type": "text",
                            "text": question
                        },

                        {
                            "type": "image_url",

                            "image_url": {
                                "url": image_url
                            }
                        }

                    ]
                }

            ]
        )

        result = response.choices[0].message.content

        return jsonify({
            "result": result.strip()
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 14. TEXT TO SPEECH
# ============================================================

@app.route("/api/tts", methods=["POST"])
def tts():

    text = request.form.get(
        "text",
        ""
    ).strip()

    voice = request.form.get(
        "voice",
        "alloy"
    ).strip()

    if not voice:
        voice = "alloy"

    if not text:
        return jsonify({
            "error": "Please enter text to speak."
        }), 400

    try:

        filename = "speech_{}.mp3".format(
            uuid.uuid4().hex
        )

        filepath = GENERATED_DIR / filename

        # Use the current streaming response pattern.
        #
        # This writes the audio directly to a file and avoids
        # keeping the complete audio object in memory.

        with client.audio.speech.with_streaming_response.create(

            model=TTS_MODEL,
            voice=voice,
            input=text

        ) as response:

            response.stream_to_file(filepath)

        audio_url = url_for(
            "static",
            filename="generated/{}".format(filename)
        )

        return jsonify({
            "url": audio_url
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 15. SPEECH TO TEXT
# ============================================================

@app.route("/api/transcribe", methods=["POST"])
def transcribe():

    audio = request.files.get("audio")

    if not audio:

        return jsonify({
            "error": "Please select an audio file."
        }), 400

    if not audio.filename:

        return jsonify({
            "error": "The uploaded file has no filename."
        }), 400

    if not allowed_audio(audio.filename):

        return jsonify({
            "error": "Unsupported audio format."
        }), 400

    safe_name = secure_filename(
        audio.filename
    )

    temporary_filename = "{}_{}".format(
        uuid.uuid4().hex,
        safe_name
    )

    temporary_path = UPLOAD_DIR / temporary_filename

    audio.save(temporary_path)

    try:

        with temporary_path.open("rb") as audio_file:

            transcript = client.audio.transcriptions.create(

                model=STT_MODEL,
                file=audio_file

            )

        return jsonify({
            "result": transcript.text.strip()
        })

    except Exception as exc:

        return error_response(exc)

    finally:

        try:
            temporary_path.unlink()
        except FileNotFoundError:
            pass


# ============================================================
# 16. AUDIO TRANSLATION
# ============================================================

@app.route("/api/audio-translate", methods=["POST"])
def audio_translate():

    audio = request.files.get("audio")

    if not audio:

        return jsonify({
            "error": "Please select an audio file."
        }), 400

    if not audio.filename:

        return jsonify({
            "error": "The uploaded file has no filename."
        }), 400

    if not allowed_audio(audio.filename):

        return jsonify({
            "error": "Unsupported audio format."
        }), 400

    safe_name = secure_filename(
        audio.filename
    )

    temporary_filename = "{}_{}".format(
        uuid.uuid4().hex,
        safe_name
    )

    temporary_path = UPLOAD_DIR / temporary_filename

    audio.save(temporary_path)

    try:

        # The audio translation endpoint currently translates
        # audio into English.

        with temporary_path.open("rb") as audio_file:

            transcript = client.audio.translations.create(

                model="whisper-1",
                file=audio_file

            )

        return jsonify({
            "result": transcript.text.strip()
        })

    except Exception as exc:

        return error_response(exc)

    finally:

        try:
            temporary_path.unlink()
        except FileNotFoundError:
            pass


# ============================================================
# 17. STREAMING TEXT
# ============================================================

@app.route("/api/stream", methods=["POST"])
def stream_demo():

    prompt = request.form.get(
        "prompt",
        "Write a short poem about innovation."
    ).strip()

    if not prompt:
        return jsonify({
            "error": "Please enter a prompt."
        }), 400

    try:

        stream = client.chat.completions.create(

            model=TEXT_MODEL,

            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],

            stream=True
        )

        chunks = []

        for chunk in stream:

            if not chunk.choices:
                continue

            delta = chunk.choices[0].delta

            if delta.content:
                chunks.append(delta.content)

        result = "".join(chunks).strip()

        return jsonify({
            "result": result
        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 18. HEALTH CHECK
# ============================================================

@app.route("/health", methods=["GET"])
def health():

    return jsonify({

        "status": "ok",

        "message": "Flask application is running.",

        "text_model": TEXT_MODEL,

        "image_model": IMAGE_MODEL,

        "tts_model": TTS_MODEL,

        "stt_model": STT_MODEL

    })


# ============================================================
# 19. API CONNECTION TEST
# ============================================================
#
# Open:
#
#     /api/test
#
# to check that the PythonAnywhere application can actually
# communicate with OpenAI.
#
# This makes a small API request.
#

@app.route("/api/test", methods=["GET"])
def api_test():

    try:

        response = client.chat.completions.create(

            model=TEXT_MODEL,

            messages=[
                {
                    "role": "user",
                    "content": "Reply with exactly: API connection works."
                }
            ],

            max_tokens=20
        )

        result = response.choices[0].message.content.strip()

        return jsonify({

            "status": "ok",

            "message": result,

            "model": TEXT_MODEL

        })

    except Exception as exc:

        return error_response(exc)


# ============================================================
# 20. LOCAL DEVELOPMENT ONLY
# ============================================================

if __name__ == "__main__":

    # This is used only when running:
    #
    #     python flask_app.py
    #
    # On PythonAnywhere, the application is loaded through
    # the WSGI file instead.

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )
    