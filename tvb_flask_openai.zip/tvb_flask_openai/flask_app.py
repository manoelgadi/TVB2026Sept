from pathlib import Path
import base64
import csv
import io
import os
import uuid

from flask import Flask, jsonify, redirect, render_template, request, send_file, url_for
from openai import OpenAI
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
GENERATED_DIR = STATIC_DIR / "generated"
UPLOAD_DIR = STATIC_DIR / "uploads"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def read_key(filename: str) -> str:
    path = BASE_DIR / filename
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {filename}. Put it in the same directory as flask_app.py."
        )
    return path.read_text(encoding="utf-8").strip()


# Same authentication approach as the notebook:
# keep the API key and organization ID outside the Python source.
API_KEY = os.getenv("OPENAI_API_KEY") or read_key("api_key.txt")
API_ORG = os.getenv("OPENAI_ORG_ID") or read_key("api_org.txt")

client_kwargs = {"api_key": API_KEY}
if API_ORG:
    client_kwargs["organization"] = API_ORG
client = OpenAI(**client_kwargs)

# Model defaults. Override them in PythonAnywhere environment variables if needed.
TEXT_MODEL = os.getenv("OPENAI_TEXT_MODEL", "gpt-5-mini")
IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")
TTS_MODEL = os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts")
STT_MODEL = os.getenv("OPENAI_STT_MODEL", "gpt-4o-mini-transcribe")

ALLOWED_AUDIO_EXTENSIONS = {"mp3", "wav", "m4a", "mp4", "mpeg", "mpga", "webm"}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25 MB upload limit


# ---------- Helpers ----------


def text_response(prompt: str, system_prompt: str | None = None) -> str:
    if system_prompt:
        response = client.responses.create(
            model=TEXT_MODEL,
            instructions=system_prompt,
            input=prompt,
        )
    else:
        response = client.responses.create(model=TEXT_MODEL, input=prompt)
    return response.output_text.strip()


def allowed_audio(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_AUDIO_EXTENSIONS


# ---------- Pages ----------


@app.route("/")
def index():
    return render_template("index.html", text_model=TEXT_MODEL, image_model=IMAGE_MODEL)


# ---------- Text examples from the notebook ----------


@app.post("/api/ask")
def ask():
    prompt = request.form.get("prompt", "").strip()
    if not prompt:
        return jsonify(error="Please enter a question."), 400
    try:
        return jsonify(result=text_response(prompt))
    except Exception as exc:
        return jsonify(error=str(exc)), 500


@app.post("/api/sentiment")
def sentiment():
    statement = request.form.get("statement", "").strip()
    if not statement:
        return jsonify(error="Please enter a statement."), 400
    try:
        result = text_response(
            statement,
            system_prompt=(
                "You are a sentiment analyzer. "
                "Answer with exactly one lowercase word: positive or negative."
            ),
        )
        return jsonify(result=result)
    except Exception as exc:
        return jsonify(error=str(exc)), 500


@app.post("/api/translate")
def translate():
    statement = request.form.get("statement", "").strip()
    language = request.form.get("language", "Irish").strip() or "Irish"
    if not statement:
        return jsonify(error="Please enter text to translate."), 400
    try:
        result = text_response(f"Translate the following text to {language}:\n\n{statement}")
        return jsonify(result=result)
    except Exception as exc:
        return jsonify(error=str(exc)), 500


@app.post("/api/tagline")
def tagline():
    company = request.form.get("company", "Ferrari").strip() or "Ferrari"
    try:
        result = text_response(
            f"Write a memorable tagline for {company} in 15 words or fewer. "
            f"Use the word {company}."
        )
        return jsonify(result=result)
    except Exception as exc:
        return jsonify(error=str(exc)), 500


# ---------- Image generation ----------


@app.post("/api/image")
def image_generate():
    prompt = request.form.get("prompt", "").strip()
    if not prompt:
        return jsonify(error="Please enter an image prompt."), 400
    try:
        result = client.images.generate(
            model=IMAGE_MODEL,
            prompt=prompt,
            size="1024x1024",
        )

        # Newer image models often return base64 data; legacy image models may return a URL.
        item = result.data[0]
        if getattr(item, "b64_json", None):
            image_bytes = base64.b64decode(item.b64_json)
            filename = f"generated_{uuid.uuid4().hex}.png"
            path = GENERATED_DIR / filename
            path.write_bytes(image_bytes)
            return jsonify(url=url_for("static", filename=f"generated/{filename}"))

        if getattr(item, "url", None):
            return jsonify(url=item.url)

        return jsonify(error="The image API returned no usable image data."), 500
    except Exception as exc:
        return jsonify(error=str(exc)), 500


# ---------- Vision: equivalent to the notebook's image URL example ----------


@app.post("/api/vision")
def vision():
    image_url = request.form.get("image_url", "").strip()
    question = request.form.get("question", "What's in this image?").strip()
    if not image_url:
        return jsonify(error="Please provide a public image URL."), 400
    try:
        response = client.responses.create(
            model=TEXT_MODEL,
            input=[
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": question},
                        {"type": "input_image", "image_url": image_url},
                    ],
                }
            ],
        )
        return jsonify(result=response.output_text.strip())
    except Exception as exc:
        return jsonify(error=str(exc)), 500


# ---------- Text-to-speech ----------


@app.post("/api/tts")
def tts():
    text = request.form.get("text", "").strip()
    voice = request.form.get("voice", "alloy").strip() or "alloy"
    if not text:
        return jsonify(error="Please enter text to speak."), 400
    try:
        speech_file = GENERATED_DIR / f"speech_{uuid.uuid4().hex}.mp3"
        response = client.audio.speech.create(
            model=TTS_MODEL,
            voice=voice,
            input=text,
            response_format="mp3",
        )
        response.write_to_file(speech_file)
        return jsonify(url=url_for("static", filename=f"generated/{speech_file.name}"))
    except Exception as exc:
        return jsonify(error=str(exc)), 500


# ---------- Speech-to-text ----------


@app.post("/api/transcribe")
def transcribe():
    audio = request.files.get("audio")
    if not audio or not audio.filename:
        return jsonify(error="Please select an audio file."), 400
    if not allowed_audio(audio.filename):
        return jsonify(error="Unsupported audio format."), 400

    filename = f"{uuid.uuid4().hex}_{secure_filename(audio.filename)}"
    path = UPLOAD_DIR / filename
    audio.save(path)

    try:
        with path.open("rb") as audio_file:
            result = client.audio.transcriptions.create(
                model=STT_MODEL,
                file=audio_file,
            )
        return jsonify(result=result.text.strip())
    except Exception as exc:
        return jsonify(error=str(exc)), 500
    finally:
        path.unlink(missing_ok=True)


# ---------- Simple streaming demo ----------


@app.post("/api/stream")
def stream_demo():
    # Kept intentionally simple: returns the generated text instead of wiring
    # browser-side server-sent events. The notebook's stream=True example is
    # still demonstrated here conceptually via a streaming iterator.
    prompt = request.form.get("prompt", "Write a short poem about innovation.").strip()
    if not prompt:
        return jsonify(error="Please enter a prompt."), 400
    try:
        stream = client.responses.create(
            model=TEXT_MODEL,
            input=prompt,
            stream=True,
        )
        chunks = []
        for event in stream:
            if getattr(event, "type", "") == "response.output_text.delta":
                chunks.append(event.delta)
        return jsonify(result="".join(chunks).strip())
    except Exception as exc:
        return jsonify(error=str(exc)), 500


# ---------- Optional local download helper ----------


@app.get("/health")
def health():
    return jsonify(status="ok", text_model=TEXT_MODEL, image_model=IMAGE_MODEL)


if __name__ == "__main__":
    # Safe for local testing. PythonAnywhere imports app through WSGI and
    # therefore does not execute this block.
    app.run(host="127.0.0.1", port=5000, debug=True)
