# TVB 2026 - Flask + OpenAI API Lab

A small Flask application adapted from the TVB OpenAI API notebook. It provides browser tests for:

- basic text prompting
- sentiment analysis
- translation
- startup taglines
- image generation
- image understanding (vision via public URL)
- text-to-speech
- speech-to-text
- a simple server-side streaming example

## Files

```text
flask_app.py
requirements.txt
api_key.txt
api_org.txt
templates/
  index.html
static/
  generated/
  uploads/
```

Keep `api_key.txt` and `api_org.txt` next to `flask_app.py`. Do not upload either file to GitHub or expose their contents in HTML/JavaScript.

## Local test

```bash
pip install -r requirements.txt
python flask_app.py
```

Then open http://127.0.0.1:5000

## PythonAnywhere

Create a Flask web app, upload this folder, install the requirements in the selected virtualenv, and set the WSGI file to import:

```python
from flask_app import app as application
```

Do not call `app.run()` from the WSGI file. The guarded `app.run()` in `flask_app.py` is only for local testing.

### Model overrides

The defaults are selected for a current API setup, but can be changed using environment variables or directly in `flask_app.py`:

```text
OPENAI_TEXT_MODEL
OPENAI_IMAGE_MODEL
OPENAI_TTS_MODEL
OPENAI_STT_MODEL
```

The notebook used older model names such as `gpt-3.5-turbo`, `dall-e-3`, `tts-1`, and `whisper-1`; these are intentionally not hard-coded as the application's defaults.
